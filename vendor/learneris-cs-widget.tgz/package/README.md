# @learneris/cs-widget

Customer success chatbot widget for all Learneris customer-facing apps.

## Install

```bash
npm i @learneris/cs-widget
```

## Use (Vite + React)

```tsx
import { CSWidget } from "@learneris/cs-widget";
import "@learneris/cs-widget/styles.css";

<CSWidget
  app="lms"
  identity={{ userId, userEmail, role, orgId, sessionToken }}
  gatewayUrl={import.meta.env.VITE_CS_GATEWAY_URL}
  gatewayKey={import.meta.env.VITE_CS_GATEWAY_KEY}
/>;
```

## Use (Next.js App Router)

```tsx
"use client";
import { CSWidget } from "@learneris/cs-widget";
import "@learneris/cs-widget/styles.css";

export function StudioWidget({ identity }: { identity: any }) {
  return (
    <CSWidget
      app="studio"
      identity={identity}
      gatewayUrl={process.env.NEXT_PUBLIC_CS_GATEWAY_URL}
      gatewayKey={process.env.NEXT_PUBLIC_CS_GATEWAY_KEY}
    />
  );
}
```

Mount once at the root layout. The widget renders a fixed-position bubble.

## Identity

For anonymous landing visitors, omit `identity`. For authenticated apps, pass:

- `userId`, `userEmail`, `role`, `orgId` — pulled from the host app's session
- `sessionToken` — a short-lived JWT signed by the host app's shared secret
  (the gateway verifies via `CS_SHARED_AUTH_SECRETS_JSON`)

## Events

```tsx
<CSWidget
  app="landing"
  onEvent={(e) => console.log(e)}
  // { type: "opened" | "closed" | "message_sent" | ... }
/>
```
